NTPort Library 2.8 Evaluation Version
Copyright (c) 1997-2008 Hai Li, Zeal SoftStudio.
E-mail: info@zealsoft.com
Homepage: http://www.zealsoft.com/
Date: Feburary 13, 2008

Description
-----------
NTPort Library enables your Win32 application to real-time direct access to PC I/O ports without using the Windows Drivers Development Kit(DDK) - NTPort Library provides support for Windows 95/98/ME and Windows NT/2000/XP/Server 2003/Vista (x86 and x64). NTPort Library is easy to use. Under Windows NT, NTPort Library driver can be load and unload dynamically, so you need not any configuration. NTPort Library is also an ideal replacement of old BASIC INP or OUT statement. The tool also supports getting the base address of LPT ports.

You need administrative right to install this product. After installation, any users can use this product. This version supports both administrator and non-administrator accounts.

Visual Basic, Visual Basic.NET, Visual C#, Visual C+, Delphi, Delphi for .NET, Borland C++ Builder, C#Builder, JBuilder, Eclipse and PowerBASIC samples are included. Matlab, Borland C++, Visual Fortran, Visual J++, InstallShield and Setup Factory samples are available for download at http://www.zealsoft.com/ntport/download.html.

Registration
------------
The non-evaluation use of NTPort Library in a business, commercial, government or institutional environment requires a license. Please read ntport.hlp for details. The registered version will not show the nag screen.

Upgrade Issue
-------------
If you are the registered user of previous version of NTPort Library, please notice the evaluation version of NTPort Library can't be turned to the registered version even if you have the valid serial number. Please visit http://www.zealsoft.com/upgrade/ to download the upgrade version. Before install the upgrade version, you must install the previous registered copy of NTPort Library.

NTPort Library 2.8 is fully compatible with previous versions.

History
-------
2.8	
	Support Windows Vista (x86 and x64).
	Support JBuilder 2007 and Eclipse.
	Support x64 version in Windows Installer Merge Module.
	Remove Wise Installation System 8.0 sample. 
	Replace ntport.hlp with ntport.chm.
	Support Visual Studio 2008 and CodeGear RAD Studio 2007.
	Replace ntport.hlp with ntport.chm.
2.7	Add Windows XP/Server 2003 x64 edition driver.
	Fix the bug that calling IsWin64 function will cause access violation error(#40048).
	Support Borland Developer Studio 2006.
	Support Visual Studio 2005.
2.6.1	Fix the bug that Setup program can't start NTPort Library Driver, Error: 1073(#40040).
2.6	GetLPTPortAddress function supports MosChip/NetMos PCI parallel ports cards.
	Add IsWin64 function.
	Add stand-alone driver setup program(Registered copy only).
	Add print manual(.pdf).
	Add Delphi for .NET samples.
	Add C#Builder samples.
	Add JBuilder samples.
	Add PowerBASIC samples.
	Update FastMode sample.	
2.5	Add merge module for Windows Installer 2.0(Registered copy only).
	Fix the issue that causes a first-chance exception in Visual C#.
	Fix the issue that GetLPTPortAddress function returns incorrect value in some Windows 9x system.
2.4	Fix the issue that displays a first chance exception in VC++ Debug Output window.
	Add Visual Basic.NET samples
	Add Visual C# samples
	Add Visual C++ Console sample.
2.3	Add GetLPTPortAddress function
	Increase the performance under all platforms and all modes
	Add LPTPort sample
2.2	Add SetFastMode and GetFastMode functions to increase the performance
	Add FastMode sample
	Add Delphi ClassTest sample
2.1	Support both administrator and non-administrator account
	Add Borland C++ Builder samples
	Add several installation templates and demos.
2.0	Increase the performance under Windows NT/2000
	Support Windows 2000
	Add a Visual C++ Sample
1.0 	Initial Version.