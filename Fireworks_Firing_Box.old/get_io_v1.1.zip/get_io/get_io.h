/*
 ******************************************************************************
 *
 * DLL allowing read of hardware I/O resources for devices from Windows
 * registry.  This provides a convenient wrapper around the Windows PnP
 * routines for easier access to this information.
 *
 * NB: If including the file "setupapi.h", it must ALWAYS be included BEFORE
 * this include file, otherwise the code will not compile.
 *
 * (c) Graham Bartlett, 2004
 * 
 * This file is part of the get_io library of the PortIO project.
 * 
 * PortIO is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * PortIO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PortIO; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 ******************************************************************************
 */

#ifndef _GET_IO_H
#define _GET_IO_H


/* 
 * Force to use C function calls.
 */
#ifdef __cplusplus
extern "C"
{
#endif


/*
 ******************************************************************************
 * Include files required to use this header
 ******************************************************************************
 */

#include <windows.h>


/*
 ******************************************************************************
 * Data types used to pass back device I/O data
 ******************************************************************************
 */

/*
 * Range of I/O addresses used.
 */
typedef struct
{
    USHORT min;
    USHORT max;
} DEVICE_IO;

/*
 * Range of memory addresses used.
 */
typedef struct
{
    ULONGLONG min;
    ULONGLONG max;
} DEVICE_MEM;

/*
 * IRQs used.
 */
typedef struct
{
    UCHAR irq;
} DEVICE_IRQ;

/*
 * DMA channels used.
 */
typedef struct
{
    UCHAR dma;
} DEVICE_DMA;

/*
 * All hardware I/O resources combined to return data to user.
 */
typedef struct
{
    ULONG num_io_ranges;
    ULONG num_mem_ranges;
    ULONG num_irqs;
    ULONG num_dmas;

    DEVICE_IO * io;
    DEVICE_MEM * mem;
    DEVICE_IRQ * irq;
    DEVICE_DMA * dma;
} DEVICE_RESOURCES;


/*
 ******************************************************************************
 * Definitions for storing data about device.  Basically this is internal data,
 * but it needs to be made externally available so that the user can capture a
 * specific device and make repeated accesses to that device's I/O data.  The
 * user does NOT need to know about what these do (and to be perfectly honest,
 * I don't know what half of it does either, as it's Windows-internal stuff).
 ******************************************************************************
 */

#ifndef GUID_DEFINED
#define GUID_DEFINED
typedef struct _GUID
{
    unsigned long Data1;
    unsigned short Data2;
    unsigned short Data3;
    unsigned char Data4[8];
} GUID;
#endif /* GUID_DEFINED */

#ifndef _INC_SETUPAPI
typedef struct _SP_DEVINFO_DATA {
    DWORD cbSize;
    GUID  ClassGuid;
    DWORD DevInst;    // DEVINST handle
    DWORD Reserved;
} SP_DEVINFO_DATA;
#endif /* _INC_SETUPAPI */

typedef PVOID HDEVINFO;

typedef struct
{
    HDEVINFO  class_handle;
    SP_DEVINFO_DATA device;
} DEVICE_DATA;

 
/*
 ******************************************************************************
 * Function declarations
 ******************************************************************************
 */

/*
 * Get number of device classes in system.
 *
 * TRUE: Success.
 * FALSE: Error (either in registry accesses or in memory allocation).
 */

BOOL GetNumIODeviceClasses( ULONG * num_classes );
                    

/*
 * Get number of characters in class name (including zero terminator) for a
 * device class.
 *
 * TRUE: Success.
 * FALSE: Error (invalid index, or error in registry accesses or in memory
 * allocation).
 */

#ifdef UNICODE
#define GetIODeviceClassNameLength    GetIODeviceClassNameLengthW
#else
#define GetIODeviceClassNameLength    GetIODeviceClassNameLengthA
#endif

BOOL GetIODeviceClassNameLengthA( ULONG class_index,
                                    ULONG * name_length );

BOOL GetIODeviceClassNameLengthW( ULONG class_index,
                                    ULONG * name_length );


/*
 * Get class name for a device class.  Pass size of string to function.
 * Function passes back actual number of characters in name.  If string is too
 * small, name will be truncated to fit into string and function returns FALSE.
 *
 * TRUE: Success.
 * FALSE: Error (invalid index, string too small, or error in registry accesses
 * or in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceClassName    GetIODeviceClassNameW
#else
#define GetIODeviceClassName    GetIODeviceClassNameA
#endif

BOOL GetIODeviceClassNameA( ULONG class_index,
                            char * name,
                            ULONG * name_length );

BOOL GetIODeviceClassNameW( ULONG class_index,
                            WCHAR * name,
                            ULONG * name_length );


/*
 * Get number of devices in a device class.
 *
 * TRUE: Success.
 * FALSE: Error (invalid class name, or error in registry accesses or in memory
 * allocation).
 */

#ifdef UNICODE
#define GetNumIODevices GetNumIODevicesW
#else
#define GetNumIODevices GetNumIODevicesA
#endif

BOOL GetNumIODevicesA( char * class_name,
                        ULONG * num_devices );

BOOL GetNumIODevicesW( WCHAR * class_name,
                        ULONG * num_devices );


/*
 * Get data for a device in a device class.  This is then used to get I/O
 * resources and to access the registry.
 *
 * TRUE: Success.
 * FALSE: Error (invalid class name, or error in registry accesses or in memory
 * allocation).
 */

#ifdef UNICODE
#define GetIODevice GetIODeviceW
#else
#define GetIODevice GetIODeviceA
#endif

BOOL GetIODeviceA( char * class_name,
                    ULONG device_index,
                    DEVICE_DATA * device_data );

BOOL GetIODeviceW( WCHAR * class_name,
                    ULONG device_index,
                    DEVICE_DATA * device_data );

/*
 * Get I/O resources for a device.
 *
 * TRUE: Success.
 * FALSE: Error (invalid class name, invalid index, or error in registry
 * accesses or in memory allocation).
 */

BOOL GetIODeviceResources( DEVICE_DATA * device_data,
                            DEVICE_RESOURCES * resources );


/*
 * Free memory used by structure for I/O resources.
 */

void FreeIODeviceResources( DEVICE_RESOURCES * resources );


/*
 * Free memory/handles used when working with device.
 */

void FreeIODevice( DEVICE_DATA * device );


/*
 * Get details of a registry entry for a device.  If succeeds, returns
 * type of registry entry in entry_type (see help for RegQueryValueEx function
 * for details of enumeration), and size of data required to store entry (in
 * bytes).  Entry type and entry size are optional (although if both are
 * omitted then the function does nothing beyond checking that the registry
 * entry exists).
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide registry entry requested, other error
 * in registry access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceRegistryDetails  GetIODeviceRegistryDetailsW
#else
#define GetIODeviceRegistryDetails  GetIODeviceRegistryDetailsA
#endif

BOOL GetIODeviceRegistryDetailsA( DEVICE_DATA * device_data,
                                    char * reg_entry_name,
                                    ULONG * entry_type,
                                    ULONG * entry_size );

BOOL GetIODeviceRegistryDetailsW( DEVICE_DATA * device_data,
                                    WCHAR * reg_entry_name,
                                    ULONG * entry_type,
                                    ULONG * entry_size );


/*
 * Read registry entry for a device.  The buffer must be large enough to store
 * this data (at least as large as the size returned by the function above).
 * Buffer size parameter is set to size of data in bytes.
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide registry entry requested, other error
 * in registry access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceRegistryValue  GetIODeviceRegistryValueW
#else
#define GetIODeviceRegistryValue  GetIODeviceRegistryValueA
#endif

BOOL GetIODeviceRegistryValueA( DEVICE_DATA * device_data,
                                    char * reg_entry_name,
                                    void * buffer,
                                    ULONG * buffer_size );

BOOL GetIODeviceRegistryValueW( DEVICE_DATA * device_data,
                                    WCHAR * reg_entry_name,
                                    void * buffer,
                                    ULONG * buffer_size );


/*
 * Get size of buffer (in characters) required for "friendly name" entry for
 * device.
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide friendly name, other error in registry
 * access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceFriendlyNameSize GetIODeviceFriendlyNameSizeW
#else
#define GetIODeviceFriendlyNameSize GetIODeviceFriendlyNameSizeA
#endif

BOOL GetIODeviceFriendlyNameSizeW( DEVICE_DATA * device_data,
                                    ULONG * size );

BOOL GetIODeviceFriendlyNameSizeA( DEVICE_DATA * device_data,
                                    ULONG * size );


/*
 * Read "friendly name" entry for a device.  The buffer must be large enough
 * to store this data (at least as large as the size returned by the function
 * above).  Buffer size parameter is set to size of name in characters.
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide friendly name, other error in registry
 * access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceFriendlyName GetIODeviceFriendlyNameW
#else
#define GetIODeviceFriendlyName GetIODeviceFriendlyNameA
#endif

BOOL GetIODeviceFriendlyNameA( DEVICE_DATA * device_data,
                                    char * friendly_name,
                                    ULONG * buffer_size );

BOOL GetIODeviceFriendlyNameW( DEVICE_DATA * device_data,
                                    WCHAR * friendly_name,
                                    ULONG * buffer_size );



/*
 * Get size of buffer (in characters) required for description entry for
 * device.
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide description, other error in registry
 * access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceDescriptionSize GetIODeviceDescriptionSizeW
#else
#define GetIODeviceDescriptionSize GetIODeviceDescriptionSizeA
#endif

BOOL GetIODeviceDescriptionSizeW( DEVICE_DATA * device_data,
                                    ULONG * size );

BOOL GetIODeviceDescriptionSizeA( DEVICE_DATA * device_data,
                                    ULONG * size);


/*
 * Read description entry for a device.  The buffer must be large enough
 * to store this data (at least as large as the size returned by the function
 * above).  Buffer size parameter is set to size of name in characters.
 *
 * TRUE: Success.
 * FALSE: Error (device does not provide description, other error in registry
 * access, or error in memory allocation).
 */

#ifdef UNICODE
#define GetIODeviceDescription GetIODeviceDescriptionW
#else
#define GetIODeviceDescription GetIODeviceDescriptionA
#endif

BOOL GetIODeviceDescriptionA( DEVICE_DATA * device_data,
                                    char * friendly_name,
                                    ULONG * buffer_size );

BOOL GetIODeviceDescriptionW( DEVICE_DATA * device_data,
                                    WCHAR * friendly_name,
                                    ULONG * buffer_size );


/*
 ******************************************************************************
 * End of file.
 ******************************************************************************
 */

/* 
 * Force to use C function calls.
 */
#ifdef __cplusplus
}
#endif

#endif	/* _GET_IO_H */
