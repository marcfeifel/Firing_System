The get_io library provides a method for easily determining the I/O resources 
used by hardware attached to a PC running Windows.

It has been tested on Windows 98, Windows 2000 and Windows XP.  It should also
work on Windows ME.  It is known NOT to work on Windows 95 and Windows NT, as 
these do not implement the same plug-and-play system as other versions of 
Windows.  It will also not work on versions of Windows earlier than Windows 95.

The get_io library forms part of the PortIO project, which provides libraries 
that may be useful in projects performing I/O functions on a PC or similar 
machine.

****

PortIO is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

PortIO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with PortIO (file "lgpl.txt"); if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
